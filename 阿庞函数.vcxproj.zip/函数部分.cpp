﻿
#include <iostream>
#include <conio.h> 
using namespace std;
 void gameView_ShowMap() {
        cout << " -----------------  "<<endl;
        cout << " 扫雷成功  (^_^)！" << endl;
        cout << "------------------    "<<endl;
        _getch();
        menuView();
        return;
    }
 void menuView();
  void  winView() {
        cout << "--------------------"<<endl;
        cout << " 扫雷失败  ╥﹏╥ ！" << endl;
        cout << "--------------------"<<endl;
        _getch();
        menuView();
        return;
    }

  int main() {
      winView();
      return 0;
   }

   
  